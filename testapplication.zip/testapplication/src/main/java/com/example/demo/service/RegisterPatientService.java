package com.example.demo.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.example.demo.Repository.DescriptionRepository;
import com.example.demo.Repository.PatientRepository;
import com.example.demo.Repository.PhysicianRepository;
import com.example.demo.exceptionClasses.DescriptionExists;
import com.example.demo.model.Description;
import com.example.demo.model.Patient;
import com.example.demo.model.Physician;
import com.example.demo.model.Plan;
@Component
public class RegisterPatientService {
	@Autowired
	PatientRepository pr;
	@Autowired
   DescriptionRepository dr;
	@Autowired
	PhysicianRepository phr;
	

	public Map<Integer,String> RegisterPatient(Patient patient)
	{
		Map<Integer,String> messages=new HashMap<>();
		
		String FirstName=patient.getFirstName();
		String LastName=patient.getLastName();
		 Optional<Set<Patient>> check = pr.findByFirstandLastName(FirstName, LastName);
		
		if(check.isEmpty())
		{
			
		if( pr.save(patient)!=null)
		{
			messages.put(1, "Success");
		 messages.put(2, "patient details saved successfully");
		 messages.put(3, "patient id is"+patient.getId());
		}
		}
		else
		{
			
			messages.put(1,"failed");
			messages.put(4,"user already exists with these details");
		}
		return messages;
	
	}
	
	
	public Map<Integer,String> saveDescription(Description description) 
	{
		
		Integer i=1;
		Patient patient = null;
		Physician physician=null;
		Map<Integer,String> messages=new HashMap<>();
		//step 1 common

		 patient=description.getPatient();
		
		 Optional<Physician> optional2=phr.findById(description.getPhysician().getId());
		
		 
		 
		if(patient!=null)
		{   
			 
			 if(optional2.isPresent())
			 {
				 physician=optional2.get();
			 }
		}
		
		
		if(patient!=null)
		{
			messages.put(1,"patientexists");
			if(physician!=null)
			   {
				messages.put(2,"Physicianexists");
			description.setPatient(patient);
			description.setPhysician(physician);
			     if((description=dr.save(description))!=null)
			        {
			         
			        messages.put(3,"success");
			        messages.put(4, "Description Id  "+description.getId());
			        }
			     else
			     {
			    	 messages.put(3,"failed");
				        messages.put(4, "Save failed");
			     }
			
		         }
	        else {
			   messages.put(2,"Physician doesn't exists");
		        
		          }
			
	       }
		else
		{
			messages.put(1,"patient doesn't exists");
			
		}
	
		return messages;
		
}
	
	
	


	public Map<Integer, String> RegisterPhysician(Physician physician) {
		
Map<Integer,String> messages=new HashMap<>();
		
		String FirstName=physician.getFirstName();
		String LastName=physician.getLastName();
		 Optional<Set<Physician>> check = phr.findByFirstandLastName(FirstName, LastName);
		
		if(check.isEmpty())
		{
			
		if( (physician=phr.save(physician))!=null)
		{
			String physicianId="PR"+"00"+physician.getId();
			
			System.out.println(physicianId);
			
			physician.setPhysicianId(physicianId);
			physician=phr.save(physician);
			
			messages.put(1, "Success");
		 messages.put(2, "physician details saved successfully");
		 messages.put(3, "physician id is"+physician.getPhysicianId());
		}
		}
		else
		{
			System.out.println("register unsucessful");
			messages.put(1,"failed");
			messages.put(4,"Physician already registered with these details");
		}
		return messages;
		
		
	}
	
	
	public Map<Physician, String> getPhysicians(Patient patient) 
	{
		Plan plan=patient.getPlan();
		
		Set<Physician> physicians=	plan.getPhysicians();
		Map<Physician,String> pairs = new HashMap<>();
		Iterator<Physician> it=physicians.iterator();
		
		while(it.hasNext())
		{ 
			Physician physician=it.next();
			System.out.println();
			pairs.put(physician,physician.getFirstName()+" "+physician.getLastName());
		
		}
        
        
        return pairs;
		
	}
	
	
	
	
	
}




/*Set<Description> descriptions=(description.getPatient().getDescriptions());  
Iterator<Description> it=descriptions.iterator();
while(it.hasNext())
{
	System.out.println(it.next().getDesp());
}  */
