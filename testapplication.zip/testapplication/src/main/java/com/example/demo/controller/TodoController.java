package com.example.demo.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Repository.DepartmentRepository;
import com.example.demo.Repository.PatientRepository;
import com.example.demo.Repository.PhysicianRepository;
import com.example.demo.Repository.PlanRepository;
import com.example.demo.Repository.StateRepository;
import com.example.demo.model.Department;
import com.example.demo.model.Description;
import com.example.demo.model.Patient;
import com.example.demo.model.Physician;
import com.example.demo.model.Plan;
import com.example.demo.model.State;
import com.example.demo.model.Todo;
import com.example.demo.service.RegisterPatientService;
import com.example.demo.service.TodoRepository;

@Controller
public class TodoController {
	
	@Autowired
	TodoRepository repository;
	@Autowired
	RegisterPatientService rps;
	@Autowired
	PhysicianRepository phr;
	@Autowired
	StateRepository sr;
	@Autowired
	PlanRepository plr;
	@Autowired
	PatientRepository pr;
	@Autowired
	DepartmentRepository dr;
	

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		// Date - dd/MM/yyyy
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(
				dateFormat, false));
	}
      
	@RequestMapping(value = "/list-todos", method = RequestMethod.GET)
	public String showTodos(ModelMap model) {
		String name = getLoggedInUserName(model);
		model.put("todos", repository.findByUser(name));
		//model.put("todos", service.retrieveTodos(name));
		return "list-todos";
	}

	private String getLoggedInUserName(ModelMap model) {
		Object principal = SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();
		
		if (principal instanceof UserDetails) {
			return ((UserDetails) principal).getUsername();
		}
		
		return principal.toString();
	}

	@RequestMapping(value = "/add-todo", method = RequestMethod.GET)
	public String showAddTodoPage(ModelMap model) {
		model.addAttribute("todo", new Todo(0, getLoggedInUserName(model),
				"Default Desc", new Date(), false));
		return "todo";
	}
	
	//showing register page
		@RequestMapping(value = "/register-physician", method = RequestMethod.GET)
		public String showRegisterPhysicianPage(ModelMap model) {
		//  Description description=new Description(0, "no description added");
		//	rps.saveorupdateDescription(description);
		//	description= dr.saveAndFlush(description);
			//model.put("states",buildState());
			
			Physician physician=new Physician();
			//patient.setDescription(description);
		
			System.out.println("-------------");
			
		
			model.addAttribute("physician", physician);
			return "registerphysician";
		}
		//registering patient
		@RequestMapping(value = "/registerphysician", method = RequestMethod.POST)
		public String RegisterPhysician(ModelMap model,@Valid Physician physician, BindingResult result) {
	        // Description description=patient.getDescription();
			// model.put("states",buildState());
			model.addAttribute("physician", physician);
			if (result.hasErrors()) {
				
				return "registerphysician";
			}

			else
			{
				
				System.out.println("===================================");
				//System.out.println(patient.getDescription().getId());
				Map<Integer,String> messages=rps.RegisterPhysician(physician);
			  if(messages.get(1).equals("Success"))
			  {
			return "redirect:/sucess";
			  }
			  else
			  {
				  String msg=messages.get(4);
				  model.addAttribute("messages", msg);
				  return "registerphysician";
			  }
			}
		}
	
	//showing patient register page
	@RequestMapping(value = "/register-patient", method = RequestMethod.GET)
	public String showRegisterPatientPage(ModelMap model) {
	//  Description description=new Description(0, "no description added");
	//	rps.saveorupdateDescription(description);
	//	description= dr.saveAndFlush(description);
		//model.put("states",buildState());
		System.out.println("desp saved===============");
		Patient patient=new Patient();
		//patient.setDescription(description);
	
		System.out.println("-------------");
		System.out.println(patient.getId());
	//	System.out.println(patient.getDescription().getId());
		System.out.println("-------------");
		System.out.println("-------------");
		model.addAttribute("patient", patient);
		return "registerpatient";
	}
	
	//registering patient
	@RequestMapping(value = "/registerpatient", method = RequestMethod.POST)
	public String RegisterPatient(ModelMap model,@Valid Patient patient, BindingResult result) {
        // Description description=patient.getDescription();
		// model.put("states",buildState());
		model.addAttribute("patient", patient);
		if (result.hasErrors()) {
			
			return "registerpatient";
		}

		else
		{
			
			System.out.println("===================================");
			//System.out.println(patient.getDescription().getId());
			Map<Integer,String> messages=rps.RegisterPatient(patient);
		  if(messages.get(1).equals("Success"))
		  {
		return "redirect:/";
		  }
		  else
		  {
			  String msg=messages.get(4);
			  model.addAttribute("messages", msg);
			  return "registerpatient";
		  }
		}
	}
	
	
	@RequestMapping(value = "/diagnosis", method = RequestMethod.GET)
	public String showDiagnosisHome(ModelMap model) {
		List<Patient> patients=new ArrayList<>();
		
		model.addAttribute("patients", patients);
		return "prediagnosis";
	
	}
	
	@RequestMapping(value = "/findPatientToAddDiagnosis", method = RequestMethod.GET)
	public String showPatientExists(ModelMap model,@RequestParam Integer id) {
		Patient patient=new Patient();
		Optional<Patient> pat=pr.findById(id);
		if(pat.isPresent())
		{
			patient=pat.get();
			List<Patient> patients=new ArrayList<>();
			patients.add(patient);
			model.addAttribute("patients", patients);
			//model.addAttribute("message", "Patient  "+patient.getFirstName()+" "+patient.getLastName()+"exists");
			return "prediagnosis";
			
		}
		else
		{
			
			model.addAttribute("message", "Patient id doesn't Exist");
			return "prediagnosis";
		}
		
	}
	
	
	
	
	
	//showing Diagnosis page
		@RequestMapping(value = "/patient-diagnosis", method = RequestMethod.GET)
		public String showDiagnosisDetailsPage(ModelMap model,@RequestParam Integer id) {
		//  Description description=new Description(0, "no description added");
		//	rps.saveorupdateDescription(description);
		//	description= dr.saveAndFlush(description);
			
			System.out.println("desp saved===============");
			Patient patient=pr.findById(id).get();
			Description description=new Description();
			
			
			
			description.setPatient(patient);
		 //getting physicians based on plan selected
			model.addAttribute("physicians",rps.getPhysicians(patient));
		    
			model.addAttribute("description", description);
			return "diagnosis";
		}
		
		
		//registering patient
		@RequestMapping(value = "/patientDiagnosisDetails", method = RequestMethod.POST)
		public String RegisterDiagnosisDetails(ModelMap model,@Valid Description description, BindingResult result)  {
	        
			model.addAttribute("description",description);
			String view="";
			if (result.hasErrors()) {
				
				
				
				model.addAttribute("physicians",rps.getPhysicians(description.getPatient()));
				
				
				
				view="diagnosis";
			}

			else
			{
				
				
				
				Map<Integer,String> messages=rps.saveDescription(description);
				
			
			if(messages.get(1).equals("patientexists"))
			{   
				
				if(messages.get(2).equals("Physicianexists"))
				{
					
					if(messages.get(3).equals("success"))
					{
						model.put("successmsg", "Details Saved Successfully!!");
						model.put("Displayid",messages.get(4));
						 view= "sucessdisplay";
					}
					else
					{
						
						model.put("failedmsg", messages.get(3));
						view= "sucessdisplay";
					}
					
				}
				else
				{
					model.put("msg", "Physician id doesn't exists");
					view= "diagnosis";
				}
				
			}
			else
			{
				model.put("msg", "patient id doesn't exists");
				view= "diagnosis";
			}
			
			
		}   
			return view;
		}
		
		
		
	

	@RequestMapping(value = "/delete-todo", method = RequestMethod.GET)
	public String deleteTodo(@RequestParam int id) {

		//if(id==1)
			//throw new RuntimeException("Something went wrong");
		repository.deleteById(id);
		//service.deleteTodo(id);
		return "redirect:/list-todos";
	}

	@RequestMapping(value = "/update-todo", method = RequestMethod.GET)
	public String showUpdateTodoPage(@RequestParam int id, ModelMap model) {
		Todo todo = repository.findById(id).get();
		//Todo todo = service.retrieveTodo(id);
		model.put("todo", todo);
		return "todo";
	}

	@RequestMapping(value = "/update-todo", method = RequestMethod.POST)
	public String updateTodo(ModelMap model, @Validated Todo todo,
			BindingResult result) {
        
		if (result.hasErrors()) {
			return "todo";
		}

		todo.setUser(getLoggedInUserName(model));

		repository.save(todo);
		//service.updateTodo(todo);

		return "redirect:/list-todos";
	}

	@RequestMapping(value = "/add-todo", method = RequestMethod.POST)
	public String addTodo(ModelMap model, @Valid Todo todo, BindingResult result) {
         
		if (result.hasErrors()) {
			return "todo";
		}

		todo.setUser(getLoggedInUserName(model));
		repository.save(todo);
		
		/*service.addTodo(getLoggedInUserName(model), todo.getDesc(), todo.getTargetDate(),
				false);*/
		return "redirect:/list-todos";
	}
	
	
	/*
	@ModelAttribute("states")
    public Map<Integer, String> buildState() 
   
    {
	List<State> states=	sr.findAll();
		Map<Integer,String> pairs = new HashMap<>();
		Iterator<State> it=states.iterator();
		int i=1;
		while(it.hasNext())
		{ 
			State state=it.next();
			System.out.println(state.getStatename());
			pairs.put(state.getId(),state.getStatename());
			i++;
		}
        
        
        return pairs;
    } 
	   */
	//working
	
	
//states
	@ModelAttribute("states")
    public Map<State, String> buildState() 
   
    {
	List<State> states=	sr.findAll();
		Map<State,String> pairs = new HashMap<>();
		Iterator<State> it=states.iterator();
		int i=1;
		while(it.hasNext())
		{ 
			State state=it.next();
			System.out.println(state.getStatename());
			pairs.put(state,state.getStatename());
			i++;
		}
        
        
        return pairs;
    } 
	
	//plan
	@ModelAttribute("plans")
    public Map<Plan, String> buildPlans() 
   
    {
	List<Plan> plans=	plr.findAll();
		Map<Plan,String> pairs = new HashMap<>();
		Iterator<Plan> it=plans.iterator();
		
		while(it.hasNext())
		{ 
			Plan plan=it.next();
			System.out.println(plan.getPlanName());
			pairs.put(plan,plan.getPlanName());
			
		}
        
        
        return pairs;
    } 
	
	//physicians
		//@ModelAttribute("physicians")
	    public Map<Physician, String> buildPhysicians() 
	   
	    {
		List<Physician> physicians=	phr.findAll();
			Map<Physician,String> pairs = new HashMap<>();
			Iterator<Physician> it=physicians.iterator();
			
			while(it.hasNext())
			{ 
				Physician physician=it.next();
				System.out.println();
				pairs.put(physician,physician.getFirstName()+" "+physician.getLastName());
			
			}
	        
	        
	        return pairs;
	    } 

		
		//departments
		
				@ModelAttribute("departments")
			    public Map<Department, String> buildDepartments() 
			   
			    {
				List<Department> departments=	dr.findAll();
					Map<Department,String> pairs = new HashMap<>();
					Iterator<Department> it=departments.iterator();
					
					while(it.hasNext())
					{ 
						Department department=it.next();
						System.out.println();
						pairs.put(department,department.getDepartmentName());
						
					}
			        
			        
			        return pairs;
			    } 
	
}
